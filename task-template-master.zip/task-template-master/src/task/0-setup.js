export async function setup() {
  // define any steps that must be executed before the task starts
  console.log("CUSTOM SETUP");
}
